<?php

namespace App\Http\Controllers;

use App\Http\Requests\PatientDemographicRequest;
use App\Models\PatientDemographic;
use Illuminate\Http\Request;

class PatientDemographicController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return PatientDemographic::with(['rdts','vitals'])->orderBy('id', 'DESC')->get();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(PatientDemographicRequest $request)
    {
        $patient = PatientDemographic::create($request->validated());
        return $this->successResponse($patient , 'Patient créée avec succès');
        
    }



    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PatientDemographic  $patientDemographic
     * @return \Illuminate\Http\Response
     */
    public function show(PatientDemographic $patient)
    {
        return $this->successResponse($patient, null);
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PatientDemographic  $patientDemographic
     * @return \Illuminate\Http\Response
     */
    public function update(PatientDemographicRequest $request, PatientDemographic $patient)
    {
        $patient->update($request->validated());
        return $this->successResponse($patient, "Données demograhiques modifiées avec sucèss");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PatientDemographic  $patientDemographic
     * @return \Illuminate\Http\Response
     */
    public function destroy(PatientDemographic $patient)
    {
        $patient->delete();
        return $this->successResponse(null, "Patient supprimé avec succès");
    }

    public function uploadPhoto(Request $request) {
            if ($request->hasFile('photo')) {
                $photo = $request->file('photo');
                $photoName = $request['patient_id'].".".$photo->extension();

                $imagePath = public_path(). '/files';
                $photo->move($imagePath, $photoName);

                // $request->file('photo')->store('image', 'public');
                PatientDemographic::where('id',$request['patient_id'])->update(array('photo' => $photoName));

                return $photoName;
            }
    }
}
