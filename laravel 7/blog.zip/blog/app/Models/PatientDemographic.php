<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class PatientDemographic extends Model
{

    // use HasFactory;

    protected $table = 'patient_demographic';
    protected $guarded = [];

    public function rdts() {
        return $this->hasMany(RdtSreening::class,'patient_id')->where('is_active','=', 1)->orderBy('id', 'DESC');
    }

    public function vitals() {
        return $this->hasMany(VitalParameter::class,'patient_id')->where('is_active','=', 1)->orderBy('id', 'DESC');
    }


}
